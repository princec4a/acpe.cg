<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\Pjax;
use yii\widgets\Menu;
/* @var $this yii\web\View */
/* @var $searchModel backend\models\KitDepartementSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('app', 'Departements');
$this->params['breadcrumbs'][] = $this->title;

?>
<div class="kit-departement-index">
    <p>
        <?= Html::a(Yii::t('app', 'Ajouter un département'), ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?php Pjax::begin(); ?>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>
    <div class="box">
        <div class="box-header">
            <h3 class="box-title">Data Table With Full Features</h3>
        </div><!-- /.box-header -->
            <?= GridView::widget([
                'dataProvider' => $dataProvider,
                'filterModel' => $searchModel,
                'columns' => [
                    ['class' => 'yii\grid\SerialColumn'],
                    //'id',
                    ['attribute' => 'nom', 'label' => Yii::t('app', 'Nom'),],
                    ['attribute' => 'created_at', 'label' => Yii::t('app', 'Crée à'),],
                    ['attribute' => 'updated_at', 'label' => Yii::t('app', 'Modifié à'),],
                    ['class' => 'yii\grid\ActionColumn'],
                ],
            ]); ?>
    </div>
    <?php Pjax::end(); ?>
</div>