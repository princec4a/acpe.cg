<?php

use yii\helpers\Html;

/* @var $this yii\web\View */
/* @var $model backend\models\KitDepartement */

$this->title = Yii::t('app', 'Nouveau Departement');
$this->params['breadcrumbs'][] = ['label' => Yii::t('app', 'Departements'), 'url' => ['index']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="row">
<!-- SELECT2 EXAMPLE -->
<div class="col-md-6">
    <div class="box box-primary">
        <div class="box-header">
            <h3 class="box-title">Date picker</h3>
        </div>
        <div class="box-body">
            <?= $this->render('_form', [
                'model' => $model,
            ]) ?>
        </div><!-- /.box-body -->
    </div><!-- /.box -->
</div>

<div class="col-md-6">
    <div class="box box-primary">
        <div class="box-header">
            <h3 class="box-title">Date picker</h3>
        </div>
        <div class="box-body">
            <!-- Date range -->
            <div class="form-group">
                <label>Date range:</label>
                <div class="input-group">
                    <div class="input-group-addon">
                        <i class="fa fa-calendar"></i>
                    </div>
                    <input type="text" class="form-control pull-right" id="reservation">
                </div><!-- /.input group -->
            </div><!-- /.form group -->

            <!-- Date and time range -->
            <div class="form-group">
                <label>Date and time range:</label>
                <div class="input-group">
                    <div class="input-group-addon">
                        <i class="fa fa-clock-o"></i>
                    </div>
                    <input type="text" class="form-control pull-right" id="reservationtime">
                </div><!-- /.input group -->
            </div><!-- /.form group -->

            <!-- Date and time range -->
            <div class="form-group">
                <label>Date range button:</label>
                <div class="input-group">
                    <button class="btn btn-default pull-right" id="daterange-btn">
                        <i class="fa fa-calendar"></i> Date range picker
                        <i class="fa fa-caret-down"></i>
                    </button>
                </div>
            </div><!-- /.form group -->

        </div><!-- /.box-body -->
    </div><!-- /.box -->
</div>