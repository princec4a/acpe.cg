<aside class="main-sidebar">

    <section class="sidebar">

        <!-- Sidebar user panel -->
        <div class="user-panel">
            <div class="pull-left image">
                <img src="<?= $directoryAsset ?>/img/user2-160x160.jpg" class="img-circle" alt="User Image"/>
            </div>
            <div class="pull-left info">
                <p>Alexander Pierce</p>

                <a href="#"><i class="fa fa-circle text-success"></i> Online</a>
            </div>
        </div>

        <!-- search form -->
        <form action="#" method="get" class="sidebar-form">
            <div class="input-group">
                <input type="text" name="q" class="form-control" placeholder="Search..."/>
              <span class="input-group-btn">
                <button type='submit' name='search' id='search-btn' class="btn btn-flat"><i class="fa fa-search"></i>
                </button>
              </span>
            </div>
        </form>
        <!-- /.search form -->

        <?= dmstr\widgets\Menu::widget(
            [
                'options' => ['class' => 'sidebar-menu tree', 'data-widget'=> 'tree'],
                'items' => [
                   // ['label' => 'Menu Yii2', 'options' => ['class' => 'header']],
                   // ['label' => 'Gii', 'icon' => 'file-code-o', 'url' => ['/gii']],
                   // ['label' => 'Debug', 'icon' => 'dashboard', 'url' => ['/debug']],
                   // ['label' => 'Login', 'url' => ['site/login'], 'visible' => Yii::$app->user->isGuest],
                    [
                        'label' => Yii::t('app', 'Gestion des dossiers'),
                        'icon' => 'folder',
                        'url' => '#',
                        'items' => [
                            ['label' => Yii::t('app', 'Demandes'), 'icon' => 'circle-o', 'url' => ['/management/demande'],],
                            ['label' => Yii::t('app', 'Employes'), 'icon' => 'circle-o', 'url' => ['/management/employe'],],
                            ['label' => Yii::t('app', 'Entreprises'), 'icon' => 'circle-o', 'url' => ['/management/entreprise'],],
                        ],
                    ],
                    [
                        'label' => Yii::t('app', 'Parametres'),
                        'icon' => 'gears',
                        'url' => '#',
                        'items' => [
                            ['label' => Yii::t('app', 'Type pièce ID'), 'icon' => 'circle-o', 'url' => ['/settings/type-piece-identite'],],
                            ['label' => Yii::t('app', 'Type autorisation'), 'icon' => 'circle-o', 'url' => ['/settings/type-autorisation'],],
                            ['label' => Yii::t('app', 'Type U.O'), 'icon' => 'circle-o', 'url' => ['/settings/type-uo'],],
                            ['label' => Yii::t('app', 'Type pièce à fournir'), 'icon' => 'circle-o', 'url' => ['/settings/piece-fournir'],],
                            ['label' => Yii::t('app', 'Unité organisationnelle'), 'icon' => 'circle-o', 'url' => ['/settings/uo'],],
                            ['label' => Yii::t('app', 'Constitution d\'un dossier'), 'icon' => 'circle-o', 'url' => ['/settings/type-autorisation-piece'],],
                            /*[
                                'label' => 'Level One',
                                'icon' => 'circle-o',
                                'url' => '#',
                                'items' => [
                                    ['label' => 'Level Two', 'icon' => 'circle-o', 'url' => '#',],
                                    [
                                        'label' => 'Level Two',
                                        'icon' => 'circle-o',
                                        'url' => '#',
                                        'items' => [
                                            ['label' => 'Level Three', 'icon' => 'circle-o', 'url' => '#',],
                                            ['label' => 'Level Three', 'icon' => 'circle-o', 'url' => '#',],
                                        ],
                                    ],
                                ],
                            ],*/
                        ],
                    ],
                ],
            ]
        ) ?>

    </section>

</aside>
