<?php

use yii\helpers\Html;
use yii\grid\GridView;
use yii\widgets\Pjax;
/* @var $this yii\web\View */
/* @var $searchModel backend\models\KitUoSearch */
/* @var $dataProvider yii\data\ActiveDataProvider */

$this->title = Yii::t('app', 'Unités Organisationnelles');
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="kit-uo-index">
    <p>
        <?= Html::a(Html::tag('i', '', ['class' => 'fa fa-fw fa-plus']) . Yii::t('app', ' Ajouter une d\'unité organiationnelle'), ['create'], ['class' => 'btn btn-success']) ?>
    </p>

    <?php Pjax::begin(); ?>
    <?php // echo $this->render('_search', ['model' => $searchModel]); ?>
    <div class="box">
        <div class="box-header with-border">
            <h3 class="box-title"><?=Yii::t('app','Liste des unités organisationnelles')?></h3>
        </div><!-- /.box-header -->
        <?= GridView::widget([
            'dataProvider' => $dataProvider,
            'filterModel' => $searchModel,
            'summary'=>'',
            'columns' => [
                ['class' => 'yii\grid\SerialColumn'],

                //'id',
                'code',
                'libelle',
                [
                    'attribute'=>'type',
                    'value'=>'type0.libelle',
                ],
                [
                    'attribute'=>'parent',
                    'value' => function($model, $key, $index){
                        if($model->parent == 0)
                        {
                            return '';
                        }
                        else
                        {
                            return $model->parent0->libelle;
                        }
                    },
                ],
                //'create_at',
                //'update_at',

                ['class' => 'yii\grid\ActionColumn'],
            ],
        ]); ?>
    </div>
    <?php Pjax::end(); ?>

</div>
