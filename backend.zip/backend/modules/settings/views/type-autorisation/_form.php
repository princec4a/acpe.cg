<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model backend\models\KitTypeAutorisation */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="kit-type-autorisation-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'code')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'libelle')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'duree_validite')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'type_duree')->dropDownList(
        ['' => '', 'JOUR' => 'Jour(s)', 'SEMAINE' => 'Semaine', 'MOIS' => 'Mois', 'ANNEE'=>'Année(s)']
    ); ?>

    <?= $form->field($model, 'nationalite')->dropDownList(
        ['' => '', 'CONGOLAISE' => 'Congolaise', 'ETRANGIERE' => 'Etrangère']
    ); ?>

    <?= $form->field($model, 'signataire')->textInput() ?>

    <div class="form-group">
        <?= Html::submitButton(Html::tag('i', '', ['class' => 'fa fa-fw fa-floppy-o']) .' '.Yii::t('app', 'Enregistrer'), ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
