<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model common\models\KitPersonneIdentite */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="kit-personne-identite-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'personne_id')->textInput() ?>

    <?= $form->field($model, 'type_piece_id')->textInput() ?>

    <?= $form->field($model, 'numero')->textInput(['maxlength' => true]) ?>

    <?= $form->field($model, 'date_emission')->textInput() ?>

    <?= $form->field($model, 'date_expiration')->textInput() ?>

    <?= $form->field($model, 'create_at')->textInput() ?>

    <?= $form->field($model, 'update_at')->textInput() ?>

    <div class="form-group">
        <?= Html::submitButton(Yii::t('app', 'Save'), ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
