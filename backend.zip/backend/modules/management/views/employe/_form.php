<?php

use yii\helpers\Html;
//use yii\widgets\ActiveForm;
use wbraganca\dynamicform\DynamicFormWidget;
use yii\helpers\ArrayHelper;
use backend\models\KitTypePieceIdentite;
use backend\models\KitVille;
use kartik\select2\Select2;
//use yii\jui\DatePicker;
use kartik\date\DatePicker;
use kartik\form\ActiveForm;

/* @var $this yii\web\View */
/* @var $model common\models\KitEmploye */
/* @var $form yii\widgets\ActiveForm */

?>

<div class="kit-employe-form">

<?php $form = ActiveForm::begin([
    'id' => 'dynamic-form',
    'tooltipStyleFeedback' => true,
]); ?>
<div class="nav-tabs-custom">
    <ul class="nav nav-tabs pull-right">
        <li><a href="#tab_4-2" data-toggle="tab">Téléphone</a></li>
        <li><a href="#tab_3-2" data-toggle="tab">Identification</a></li>
        <li><a href="#tab_2-2" data-toggle="tab">Info. professionnelle</a></li>
        <li class="active"><a href="#tab_1-1" data-toggle="tab">Info. personnelle</a></li>
    </ul>
    <div class="tab-content">
        <div class="tab-pane active" id="tab_1-1">
            <?= $form->field($model, 'nom')->textInput(['maxlength' => true]) ?>

            <?= $form->field($model, 'prenom')->textInput(['maxlength' => true]) ?>

            <?= $form->field($model, 'sexe')->dropDownList(
                [
                    'HOMME'=>'Homme',
                    'FEMME'=>'Femme',
                ],
                [
                    'prompt'=>'Selectionner ...',
                    'class' => 'form-control input-sm',
                    'onchange'=>'JS: var value = (this.value);
                     console.log(value);'

                ]
            ) ?>

            <?= $form->field($model, 'nom_jeune_fille')->textInput(['maxlength' => true]) ?>

            <?= $form->field($model, 'date_naissance')->widget(
                DatePicker::className(),
                [
                    'type' => DatePicker::TYPE_COMPONENT_APPEND,
                    'pluginOptions' => [
                        'autoclose' => true,
                        'format' => 'dd/mm/yyyy',
                    ]
                ]
            );?>

            <?= $form->field($model, 'lieu_naissance')->textInput(['rows' => 6]) ?>

            <?= $form->field($model, 'nationalite')->widget(Select2::classname(), [
                'data' => ArrayHelper::map(\common\models\KitPays::find()->all(), 'id', 'nompays'),
                'options' => ['placeholder' => Yii::t('app','Selectionner')],
                'pluginOptions' => [
                    'allowClear' => true
                ],
            ]);
            ?>

            <?= $form->field($model, 'email')->textInput(['rows' => 6]) ?>

        </div><!-- /.tab-pane -->
        <div class="tab-pane" id="tab_2-2">
            <?= $form->field($model, 'entreprise_id')->widget(Select2::classname(), [
                'data' => ArrayHelper::map(\common\models\KitEntreprise::find()->all(), 'id', 'raison_sociale'),
                'options' => ['placeholder' => Yii::t('app','Selectionner')],
                'pluginOptions' => [
                    'allowClear' => true
                ],
            ]);
            ?>
            <?= $form->field($model, 'lieu_travail')->textInput(['maxlength' => true]) ?>
            <?= $form->field($model, 'ville_travail')->widget(Select2::classname(), [
                'data' => ArrayHelper::map(KitVille::find()->all(), 'id', 'nom'),
                'options' => ['placeholder' => Yii::t('app','Selectionner')],
                'pluginOptions' => [
                    'allowClear' => true
                ],
            ]);
            ?>
            <?= $form->field($model, 'statut_medical')->textInput(['maxlength' => true]) ?>
            <?= $form->field($model, 'type_contrat_id')->dropDownList(
                [
                    'CDD'=>'Contrat à Durée Déterminée',
                    'CDI'=>'Contrat à Durée Indéterminée',
                    'STG'=>'Stagiaire',
                    'TMP'=>'Temporaire',
                ],
                [
                    'prompt'=>'Selectionner ...',
                    'class' => 'form-control input-sm',
                    'onchange'=>'function()'
                ]
            ) ?>
            <?= $form->field($model, 'reference_contrat')->textInput(['maxlength' => true]) ?>

            <?= $form->field($model, 'fonction')->textInput(['maxlength' => true]) ?>

            <?= $form->field($model, 'date_embauche')->widget(
                DatePicker::className(),
                [
                    'type' => DatePicker::TYPE_COMPONENT_APPEND,
                    'pluginOptions' => [
                        'autoclose' => true,
                        'format' => 'dd/mm/yyyy',
                    ]
                ]
            );?>

            <?= $form->field($model, 'date_fin_contrat')->widget(
                DatePicker::className(),
                [
                    'type' => DatePicker::TYPE_COMPONENT_APPEND,
                    'pluginOptions' => [
                        'autoclose' => true,
                        'format' => 'dd/mm/yyyy',
                    ]
                ]
            );?>

        </div>
        <div class="tab-pane" id="tab_3-2">
            <?php DynamicFormWidget::begin([
                'widgetContainer' => 'dynamicform_wrapper',
                'widgetBody' => '.form-options-body',
                'widgetItem' => '.form-options-item',
                'min' => 1,
                'insertButton' => '.add-item',
                'deleteButton' => '.remove-item',
                'model' => $modelsOptionValue[0],
                'formId' => 'dynamic-form',
                'formFields' => [
                    'piece_fournir_id',
                    'nombre',
                    'a_joindre',
                    'obligatoire',
                    'date_effective',
                    'date_fin',
                ],

            ]); ?>

            <div class="box box-primary">
                <div class="box-header with-border">
                    <i class="fa fa-file-text"></i><?=Yii::t('app','Document d\'identification')?>
                    <button type="button" class="pull-right add-item btn btn-success btn-xs"><i class="fa fa-plus"></i> Ajouter</button>
                    <div class="clearfix"></div>
                </div>
            </div>
            <div class="form-options-body">
                <?php foreach ($modelsOptionValue as $index => $modelOptionValue): ?>
                    <div class="form-options-item">
                        <div class="panel-heading">
                            <button type="button" class="pull-right remove-item btn btn-danger btn-xs"><i class="fa fa-minus"></i></button>
                            <div class="clearfix"></div>
                        </div>
                        <?php
                        // necessary for update action.
                        if (!$modelOptionValue->isNewRecord) {
                            echo Html::activeHiddenInput($modelOptionValue, "[{$index}]id");
                        }
                        ?>
                        <div class="col-xs-8"><?= $form->field($modelOptionValue, "[{$index}]type_piece_id")->dropDownList(
                                ArrayHelper::map(KitTypePieceIdentite::find()->all(), 'id', 'libelle'),
                                [
                                    'prompt'=>'Selectionner ...',
                                    'class' => 'form-control input-sm',
                                    'onchange'=>'function()'
                                ]
                            ) ?>
                        </div>

                        <div class="col-xs-4"><?= $form->field($modelOptionValue, "[{$index}]numero")->textInput(['class' => 'form-control input-sm']) ?></div>

                        <div class="col-xs-6">
                            <?= $form->field($modelOptionValue, "[{$index}]date_emission")->widget(
                                \kartik\date\DatePicker::className(),
                                [
                                    'type' => DatePicker::TYPE_COMPONENT_APPEND,
                                    'pluginOptions' => [
                                        'autoclose' => true,
                                        'format' => 'dd/mm/yyyy',
                                    ]
                                ]
                            );?>
                        </div>

                        <div class="col-xs-6">
                            <?= $form->field($modelOptionValue, "[{$index}]date_expiration")->widget(
                                DatePicker::className(),
                                [
                                    'type' => DatePicker::TYPE_COMPONENT_APPEND,
                                    'pluginOptions' => [
                                        'autoclose' => true,
                                        'format' => 'dd/mm/yyyy',
                                    ]
                                ]
                            );?>
                        </div>

                        <div class="clearfix "></div>
                        <div class="box-footer" style="margin: 0; padding: 0;">&nbsp;</div>

                    </div>
                <?php endforeach; ?>

            </div>
            <?php DynamicFormWidget::end(); ?>
        </div><!-- /.tab-pane -->
        <div class="tab-pane" id="tab_4-2">
            <?php DynamicFormWidget::begin([
                'widgetContainer' => 'dynamicform_wrapper',
                'widgetBody' => '.form-telephone-body',
                'widgetItem' => '.form-telephone-item',
                'min' => 1,
                'insertButton' => '.add-phone',
                'deleteButton' => '.remove-phone',
                'model' => $modelsTelephone[0],
                'formId' => 'dynamic-form',
                'formFields' => [
                    'piece_fournir_id',
                    'nombre',
                    'a_joindre',
                    'obligatoire',
                    'date_effective',
                    'date_fin',
                ],

            ]); ?>

            <div class="box box-primary">
                <div class="box-header with-border">
                    <i class="fa fa-file-text"></i><?=Yii::t('app','Téléphone')?>
                    <button type="button" class="pull-right add-phone btn btn-success btn-xs"><i class="fa fa-plus"></i> Ajouter</button>
                    <div class="clearfix"></div>
                </div>
            </div>
            <div class="form-telephone-body">
                <?php foreach ($modelsTelephone as $index => $modelOptionValue): ?>
                    <div class="form-telephone-item">
                        <div class="panel-heading">
                            <span class="panel-title-address">Téléphone: <?= ($index + 1) ?></span>
                            <button type="button" class="pull-right remove-phone btn btn-danger btn-xs"><i class="fa fa-minus"></i></button>
                            <div class="clearfix"></div>
                        </div>
                        <?php
                        // necessary for update action.
                        if (!$modelOptionValue->isNewRecord) {
                            echo Html::activeHiddenInput($modelOptionValue, "[{$index}]id");
                        }
                        ?>

                        <div class="col-xs-6"><?= $form->field($modelOptionValue, "[{$index}]numero")->textInput(['class' => 'form-control input-sm']) ?></div>

                        <div class="clearfix "></div>
                        <div class="box-footer" style="margin: 0; padding: 0;">&nbsp;</div>

                    </div>
                <?php endforeach; ?>

            </div>
            <?php DynamicFormWidget::end(); ?>
        </div><!-- /.tab-pane -->
    </div><!-- /.tab-content -->
</div><!-- nav-tabs-custom -->

<div class="form-group">
    <?= Html::submitButton(Html::tag('i', '', ['class' => 'fa fa-fw fa-floppy-o']) .' '.Yii::t('app', 'Enregistrer'), ['class' => 'btn btn-success']) ?>
</div>

<?php ActiveForm::end(); ?>

</div>
