<?php

use yii\helpers\Html;
use yii\widgets\ActiveForm;

/* @var $this yii\web\View */
/* @var $model common\models\KitDemande */
/* @var $form yii\widgets\ActiveForm */
?>

<div class="kit-demande-form">

    <?php $form = ActiveForm::begin(); ?>

    <?= $form->field($model, 'employe_id')->textInput() ?>

    <?= $form->field($model, 'date_reception')->textInput() ?>

    <div class="form-group">
        <?= Html::submitButton(Html::tag('i', '', ['class' => 'fa fa-fw fa-floppy-o']) .' '.Yii::t('app', 'Enregistrer'), ['class' => 'btn btn-success']) ?>
    </div>

    <?php ActiveForm::end(); ?>

</div>
