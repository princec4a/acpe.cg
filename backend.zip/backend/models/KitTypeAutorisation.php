<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "kit_type_autorisation".
 *
 * @property int $id
 * @property string $code
 * @property string $libelle
 * @property float $duree_validite
 * @property string $type_duree
 * @property string $nationalite
 * @property int $signataire
 * @property string $create_at
 * @property string $update_at
 *
 * @property KitAutorisation[] $kitAutorisations
 * @property KitElementTypeAutorisation[] $kitElementTypeAutorisations
 */
class KitTypeAutorisation extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'kit_type_autorisation';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['code', 'libelle', 'duree_validite', 'type_duree', 'nationalite'], 'required'],
            [['duree_validite'], 'number'],
            [[ 'signataire'], 'integer'],
            [['create_at', 'update_at'], 'safe'],
            [['code', 'libelle'], 'string', 'max' => 255],
            [['type_duree','nationalite'], 'string', 'max' => 10],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'code' => Yii::t('app', 'Code'),
            'libelle' => Yii::t('app', 'Libelle'),
            'duree_validite' => Yii::t('app', 'Dureée de validité'),
            'type_duree' => Yii::t('app', 'Type Duree'),
            'nationalite' => Yii::t('app', 'Nationalite'),
            'signataire' => Yii::t('app', 'Signataire'),
            'create_at' => Yii::t('app', 'Créée le '),
            'update_at' => Yii::t('app', 'Modifiée le'),
        ];
    }

    /**
     * Gets query for [[KitAutorisations]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getKitAutorisations()
    {
        return $this->hasMany(KitAutorisation::className(), ['type_autorisation_id' => 'id']);
    }

    /**
     * Gets query for [[KitElementTypeAutorisations]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getKitElementTypeAutorisations()
    {
        return $this->hasMany(KitElementTypeAutorisation::className(), ['type_autorisation_id' => 'id']);
    }

    public static function getDataList(){
        $listData = [];
        $listArray = KitTypeAutorisation::find()
            ->orderBy('libelle')
            ->all();
        foreach($listArray as $item){
            $customerLibelle = $item->libelle . ' - '. $item->code;
            $listData[] = ["id" => $item->id, "libelle" => $customerLibelle];
        }
        return $listData;
    }
}
