<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "kit_element_type_autorisation".
 *
 * @property int $id
 * @property int $piece_fournir_id
 * @property int $type_autorisation_id
 * @property int $nombre
 * @property int $a_joindre
 * @property int $obligatoire
 * @property string $create_at
 * @property string $update_at
 * @property string $date_effective
 * @property string $date_fin
 *
 * @property KitElementDemande[] $kitElementDemandes
 * @property KitTypeAutorisationPiece $typeAutorisation
 * @property KitPieceFournir $pieceFournir
 */
class KitElementTypeAutorisation extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */

    //public $type_autorisation;

    public static function tableName()
    {
        return 'kit_element_type_autorisation';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['piece_fournir_id', 'nombre', 'a_joindre', 'obligatoire'], 'required'],
            [['piece_fournir_id', 'type_autorisation_id', 'nombre', 'a_joindre', 'obligatoire'], 'integer'],
            [['create_at', 'update_at', 'date_effective', 'date_fin'], 'safe'],
            [['type_autorisation_id'], 'exist', 'skipOnError' => true, 'targetClass' => KitTypeAutorisationPiece::className(), 'targetAttribute' => ['type_autorisation_id' => 'id']],
            [['piece_fournir_id'], 'exist', 'skipOnError' => true, 'targetClass' => KitPieceFournir::className(), 'targetAttribute' => ['piece_fournir_id' => 'id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'piece_fournir_id' => Yii::t('app', 'Type de pièce'),
            'type_autorisation_id' => Yii::t('app', 'Type d\'autorisation'),
            'nombre' => Yii::t('app', 'Nombre'),
            'a_joindre' => Yii::t('app', 'à joindre'),
            'obligatoire' => Yii::t('app', 'Obligatoire'),
            'create_at' => Yii::t('app', 'Créée le'),
            'update_at' => Yii::t('app', 'Modifiée le'),
            'date_effective' => Yii::t('app', 'Date éffective'),
            'date_fin' => Yii::t('app', 'Date fin'),
            //'type_autorisation' => Yii::t('app', 'Type d\'autorisation'),
        ];
    }

    /**
     * Gets query for [[KitElementDemandes]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getKitElementDemandes()
    {
        return $this->hasMany(KitElementDemande::className(), ['elt_type_autorisation' => 'id']);
    }

    /**
     * Gets query for [[TypeAutorisation]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getTypeAutorisation()
    {
        return $this->hasOne(KitTypeAutorisationPiece::className(), ['id' => 'type_autorisation_id']);
    }

    /**
     * Gets query for [[PieceFournir]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getPieceFournir()
    {
        return $this->hasOne(KitPieceFournir::className(), ['id' => 'piece_fournir_id']);
    }
}
