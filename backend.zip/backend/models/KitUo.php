<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "kit_uo".
 *
 * @property int $id
 * @property string $code
 * @property string $libelle
 * @property int $type
 * @property int $parent
 * @property string $create_at
 * @property string $update_at
 *
 * @property KitTypeUo $type0
 * @property KitUo $parent0
 * @property KitUo[] $kitUos
 */
class KitUo extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'kit_uo';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['code', 'libelle', 'type'], 'required'],
            [['type', 'parent'], 'integer'],
            [['create_at', 'update_at'], 'safe'],
            [['code', 'libelle'], 'string', 'max' => 255],
            [['type'], 'exist', 'skipOnError' => true, 'targetClass' => KitTypeUo::className(), 'targetAttribute' => ['type' => 'id']],
            //[['parent'], 'exist', 'skipOnError' => true, 'targetClass' => KitUo::className(), 'targetAttribute' => ['parent' => 'id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'code' => Yii::t('app', 'Code'),
            'libelle' => Yii::t('app', 'Libelle'),
            'type' => Yii::t('app', 'Type'),
            'parent' => Yii::t('app', 'U.O Parent'),
            'create_at' => Yii::t('app', 'Créer le'),
            'update_at' => Yii::t('app', 'Modifier le'),
        ];
    }

    /**
     * Gets query for [[Type0]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getType0()
    {
        return $this->hasOne(KitTypeUo::className(), ['id' => 'type']);
    }

    /**
     * Gets query for [[Parent0]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getParent0()
    {
        return $this->hasOne(KitUo::className(), ['id' => 'parent']);
    }

    /**
     * Gets query for [[KitUos]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getKitUos()
    {
        return $this->hasMany(KitUo::className(), ['parent' => 'id']);
    }
}
