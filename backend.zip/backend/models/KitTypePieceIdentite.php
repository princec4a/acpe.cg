<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "kit_type_piece_identite".
 *
 * @property int $id
 * @property string $code
 * @property string $libelle
 * @property string $create_at
 * @property string $update_at
 */
class KitTypePieceIdentite extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'kit_type_piece_identite';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['id','code', 'libelle'], 'required'],
            [['id'], 'integer'],
            [['create_at', 'update_at'], 'safe'],
            [['code'], 'string', 'max' => 10],
            [['libelle'], 'string', 'max' => 255],
            [['id'], 'unique'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'code' => Yii::t('app', 'Code'),
            'libelle' => Yii::t('app', 'Libelle'),
            'create_at' => Yii::t('app', 'Create At'),
            'update_at' => Yii::t('app', 'Update At'),
        ];
    }
}
