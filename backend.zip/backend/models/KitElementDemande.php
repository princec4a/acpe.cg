<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "kit_element_demande".
 *
 * @property int $id
 * @property int $elt_type_autorisation
 * @property string $fichier
 * @property int $demande_id
 * @property string $create_at
 * @property string $update_at
 *
 * @property KitDemande $demande
 * @property KitElementTypeAutorisation $eltTypeAutorisation
 */
class KitElementDemande extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'kit_element_demande';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['elt_type_autorisation', 'fichier', 'demande_id', 'create_at', 'update_at'], 'required'],
            [['elt_type_autorisation', 'demande_id'], 'integer'],
            [['fichier'], 'string'],
            [['create_at', 'update_at'], 'safe'],
            [['demande_id'], 'exist', 'skipOnError' => true, 'targetClass' => KitDemande::className(), 'targetAttribute' => ['demande_id' => 'id']],
            [['elt_type_autorisation'], 'exist', 'skipOnError' => true, 'targetClass' => KitElementTypeAutorisation::className(), 'targetAttribute' => ['elt_type_autorisation' => 'id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'elt_type_autorisation' => Yii::t('app', 'Elt Type Autorisation'),
            'fichier' => Yii::t('app', 'Fichier'),
            'demande_id' => Yii::t('app', 'Demande ID'),
            'create_at' => Yii::t('app', 'Create At'),
            'update_at' => Yii::t('app', 'Update At'),
        ];
    }

    /**
     * Gets query for [[Demande]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getDemande()
    {
        return $this->hasOne(KitDemande::className(), ['id' => 'demande_id']);
    }

    /**
     * Gets query for [[EltTypeAutorisation]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getEltTypeAutorisation()
    {
        return $this->hasOne(KitElementTypeAutorisation::className(), ['id' => 'elt_type_autorisation']);
    }
}
