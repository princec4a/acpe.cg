<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "kit_piece_fournir".
 *
 * @property int $id
 * @property string $code
 * @property string $nom
 * @property string $create_at
 * @property string $update_at
 *
 * @property KitElementTypeAutorisation[] $kitElementTypeAutorisations
 */
class KitPieceFournir extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'kit_piece_fournir';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['code', 'nom'], 'required'],
            [['create_at', 'update_at'], 'safe'],
            [['code'], 'string', 'max' => 10],
            [['nom'], 'string', 'max' => 255],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'code' => Yii::t('app', 'Code'),
            'nom' => Yii::t('app', 'Nom'),
            'create_at' => Yii::t('app', 'Créée le'),
            'update_at' => Yii::t('app', 'Modifié le'),
        ];
    }

    /**
     * Gets query for [[KitElementTypeAutorisations]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getKitElementTypeAutorisations()
    {
        return $this->hasMany(KitElementTypeAutorisation::className(), ['piece_fournir_id' => 'id']);
    }
}
