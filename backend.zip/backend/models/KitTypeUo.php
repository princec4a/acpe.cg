<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "kit_type_uo".
 *
 * @property int $id
 * @property string $code
 * @property string $libelle
 * @property string $create_at
 * @property string $update_at
 *
 * @property KitUo[] $kitUos
 */
class KitTypeUo extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'kit_type_uo';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['code', 'libelle'], 'required'],
            [['create_at', 'update_at'], 'safe'],
            [['code', 'libelle'], 'string', 'max' => 255],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'code' => Yii::t('app', 'Code'),
            'libelle' => Yii::t('app', 'Libelle'),
            'create_at' => Yii::t('app', 'Créer le'),
            'update_at' => Yii::t('app', 'Modifier le'),
        ];
    }

    /**
     * Gets query for [[KitUos]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getKitUos()
    {
        return $this->hasMany(KitUo::className(), ['type' => 'id']);
    }
}
