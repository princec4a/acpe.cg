<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "kit_ville".
 *
 * @property int $id
 * @property int $nom
 * @property int $pays_id
 *
 * @property KitEmploye[] $kitEmployes
 */
class KitVille extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'kit_ville';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['nom', 'pays_id'], 'required'],
            [['nom', 'pays_id'], 'integer'],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'nom' => Yii::t('app', 'Nom'),
            'pays_id' => Yii::t('app', 'Pays ID'),
        ];
    }

    /**
     * Gets query for [[KitEmployes]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getKitEmployes()
    {
        return $this->hasMany(KitEmploye::className(), ['ville_travail' => 'id']);
    }
}
