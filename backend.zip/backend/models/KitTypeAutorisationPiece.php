<?php

namespace backend\models;

use Yii;

/**
 * This is the model class for table "kit_type_autorisation_piece".
 *
 * @property int $id
 * @property int $type_autorisation_id
 *
 * @property KitElementTypeAutorisation[] $kitElementTypeAutorisations
 * @property KitTypeAutorisation $typeAutorisation
 */
class KitTypeAutorisationPiece extends \yii\db\ActiveRecord
{
    /**
     * {@inheritdoc}
     */
    public static function tableName()
    {
        return 'kit_type_autorisation_piece';
    }

    /**
     * {@inheritdoc}
     */
    public function rules()
    {
        return [
            [['type_autorisation_id'], 'required'],
            [['type_autorisation_id'], 'integer'],
            [['type_autorisation_id'], 'exist', 'skipOnError' => true, 'targetClass' => KitTypeAutorisation::className(), 'targetAttribute' => ['type_autorisation_id' => 'id']],
        ];
    }

    /**
     * {@inheritdoc}
     */
    public function attributeLabels()
    {
        return [
            'id' => Yii::t('app', 'ID'),
            'type_autorisation_id' => Yii::t('app', 'Type d\'autorisation'),
        ];
    }

    /**
     * Gets query for [[KitElementTypeAutorisations]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getKitElementTypeAutorisations()
    {
        return $this->hasMany(KitElementTypeAutorisation::className(), ['type_autorisation_id' => 'id']);
    }

    /**
     * Gets query for [[TypeAutorisation]].
     *
     * @return \yii\db\ActiveQuery
     */
    public function getTypeAutorisation()
    {
        return $this->hasOne(KitTypeAutorisation::className(), ['id' => 'type_autorisation_id']);
    }
}
